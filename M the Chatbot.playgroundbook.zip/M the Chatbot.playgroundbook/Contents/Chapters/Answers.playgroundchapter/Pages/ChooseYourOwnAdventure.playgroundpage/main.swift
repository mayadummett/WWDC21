//#-hidden-code
//
//  main.swift
//  
//  Copyright © 2016-2020 Apple Inc. All rights reserved.
//
//#-end-hidden-code
//#-code-completion(identifier, hide, setupLiveView())
//#-hidden-code
import Foundation
import UIKit
//#-end-hidden-code
//#-editable-code Tap to enter code
let bakingAdventure = Adventure()

bakingAdventure.start()
//#-end-editable-code
